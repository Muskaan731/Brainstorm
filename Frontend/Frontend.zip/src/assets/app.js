console.log("hello custome js");

