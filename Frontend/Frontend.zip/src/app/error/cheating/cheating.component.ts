import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cheating',
  templateUrl: './cheating.component.html',
  styleUrls: ['./cheating.component.css']
})
export class CheatingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
